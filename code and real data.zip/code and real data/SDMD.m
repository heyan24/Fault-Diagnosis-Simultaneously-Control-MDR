tic
warning off
alpha=0.1; 
m=3000;  %n=1;
pi0=1; pi1=0; pi2=1-pi0-pi1; %��ʼ�ֲ�
A1=3; B1=1/2; B=0.05; A2=2; B2=1/2; %mean of gamma: A1*B1
df=5;
%mu1=1.5;mu2=-1;
%rep1=100; rep2=1000; 
COVMAT=eye(m); 
A=[0.75,0.125,0.125;
    0.6,0.3,0.1;
    0.6,0.1,0.3];  %ת�Ƹ��ʾ���A(0,1,-1)
% A=[0.7,0.15,0.15;
%     0.3,0.5,0.2;
%     0.3,0.2,0.5];
% A=[0.7,0.2,0.1;
%     0.5,0.3,0.2;
%     0.5,0.3,0.2]; %���Գ����
for i=1:m
	for j=1:m
        COVMAT(i,j)=0.5^(abs(i-j));
	end
end
% Sum=m/10;
% for ss=1:Sum
%     for i=1:10
%         for j=1:10
%         	COVMAT((ss-1)*10+i,(ss-1)*10+j)=(i==j)+(i~=j)*0.3;
%         end
%     end
% end 
%N=[1,2,5,10,15,20];
N=[10];
%LAM=[0.24,0.22,0.16,0.12,0.105,0.095]; %����1��A1=2
%LAM=[0.24,0.22,0.175,0.135,0.115,0.11]; %����1��A1=3
%LAM=[0.24,0.22,0.15,0.115,0.1,0.087]; %����2��A1=2
%LAM=[0.24,0.22,0.16,0.125,0.115,0.1]; %����2��A1=3
%LAM=[0.24,0.22,0.155,0.118,0.102,0.092]; %����3��A1=2
%LAM=[0.24,0.2,0.167,0.132,0.12,0.107]; %����3��A1=3
%LAM=[0.23,0.15,0.11,0.145,0.13,0.115]; %Gamma
%LAM=[0.24,0.15,0.232,0.195,0.17,0.157]; %Gamma A1=3
%LAM=[0.225,0.155,0.13,0.12,0.102,0.091]; %t
%LAM=[0.22,0.15,0.177,0.13,0.11,0.1]; %t A1=3
%LAM=[0.22,0.2,0.164,0.13,0.115,0.107]; %���0.3��A1=3������1
LAM=[0.24,0.15,0.158,0.129,0.113,0.109]; %���0.5��A1=3������1
%LAM=[0.22,0.18,0.16,0.13,0.112,0.101]; %m=1000
rep1=10; rep2=1; 
MDR=zeros(rep1,length(N));EFP=zeros(rep1,length(N));
for r=1:length(N)
n=N(r); lam=LAM(4);
sigma=1/sqrt(n); 
%MDR=zeros(1,rep1);EFP=zeros(1,rep1);
%THETA�Ĳ�����Ҫ����HMMģ��������

for t=1:rep1
    c0=zeros(1,m);
    mu=zeros(1,m);
    THETA=zeros(1,m);
    THETA(1)=1-binornd(1,pi0); %�������A����THETA
    if THETA(1)==1
        ind=binornd(1,pi1/(pi1+pi2));
        THETA(1)=ind*1+(1-ind)*-1;
        mu(1)=ind*(gamrnd(A1,B1)+B)+(1-ind)*(-gamrnd(A2,B2)-B);
    end
    for i=2:m
        if THETA(i-1)==0
            THETA(i)=binornd(1,1-A(1,1));
            if THETA(i)==1
                ind=binornd(1,A(1,2)/(A(1,2)+A(1,3)));
                THETA(i)=ind*1+(1-ind)*-1;
                mu(i)=ind*(gamrnd(A1,B1)+B)+(1-ind)*(-gamrnd(A2,B2)-B);
            end    
        elseif THETA(i-1)==1
            THETA(i)=binornd(1,1-A(2,1));
            if THETA(i)==1
                ind=binornd(1,A(2,2)/(A(2,2)+A(2,3)));
                THETA(i)=ind*1+(1-ind)*-1;
                mu(i)=ind*(gamrnd(A1,B1)+B)+(1-ind)*(-gamrnd(A2,B2)-B);
            end
        elseif THETA(i-1)==-1
            THETA(i)=binornd(1,1-A(3,1));
            if THETA(i)==1
                ind=binornd(1,A(3,2)/(A(3,2)+A(3,3)));
                THETA(i)=ind*1+(1-ind)*-1;
                mu(i)=ind*(gamrnd(A1,B1)+B)+(1-ind)*(-gamrnd(A2,B2)-B);
            end
        end
    end
%     THETA=binornd(1,1-p0,1,m);
%     mu=zeros(1,m);
%     for i=1:m
%         if THETA(i)==1
% 		ind=binornd(1,p1/(p1+p2));
% 		THETA(i)=ind*1+(1-ind)*-1;
% 		mu(i)=ind*(gamrnd(A1,B1)+B)+(1-ind)*(-gamrnd(A2,B2)-B);
%         end
%     end
    %���ϲ�����THETA��mu��ģ��ֵ
    MU=linspace(-5,5,200); MU1=MU(101:199); MU2=MU(1:100);
	a=0;b=0;c=0;
	g1=zeros(1,m); g2=zeros(1,m); result=zeros(1,m);

	for k=1:rep2
        %X=gamrnd(3,1,n,m); X=(X-3)/sqrt(3);
        %X=trnd(df,n,m);X=X/sqrt(df/(df-2));
	    X=mvnrnd(mu,COVMAT,n); %����X��ģ��ֵ
        if n>1
            X=mean(X); 
        end
        %X=X+mu;
        [p0_e,p1_e,p2_e]=PEST_dire(X,0,sigma);
        
        Hmu=zeros(1,length(MU)-1);
        for i=1:length(Hmu)
        	Hmu(i)=hmu(1-p0_e,n,lam,X,MU(i));
        end
        Hmu1=Hmu(101:199)*(1-p0_e)/p1_e;
        Hmu2=Hmu(1:100)*(1-p0_e)/p2_e; 
        for i=1:m
            x=X(i);
            %g1_r(i)=sum(normpdf(x,MU1,sigma).*gampdf(MU1,A1,B1)/20);
            %g2_r(i)=sum(normpdf(x,MU2,sigma).*gampdf(-MU2,A2,B2)/20);
            g1(i)=sum(normpdf(x,MU1,sigma).*Hmu1/20);
            g2(i)=sum(normpdf(x,MU2,sigma).*Hmu2/20);
        end
        g0=normpdf(X,0,sigma);%g1=normpdf(X,mu1,sigma);g2=normpdf(X,mu2,sigma);
        %���Ϲ�����p0��g
        %������EM�㷨����pi��A
        Int=[0.8,0.1,0.1;
            0.8,0.1,0.1;
            0.7,0.2,0.1;
            0.7,0.1,0.2];
        [pi0_e,pi1_e,pi2_e,A_e]=EM(m,g0,g1,g2,Int);
%         if A_e(1,1)<0.6
%             break
%         end
        
        %��������forward-backward�㷨����H
        
        Alpha0=zeros(1,m); Alpha1=zeros(1,m); Alpha2=zeros(1,m);
        Beta0=zeros(1,m); Beta1=zeros(1,m); Beta2=zeros(1,m);
        Alpha0(1)=pi0_e*g0(1); Alpha1(1)=pi1_e*g1(1); Alpha2(1)=pi2_e*g2(1);
        c0(1)=1/(Alpha0(1)+Alpha1(1)+Alpha2(1));
        Alpha0(1)=Alpha0(1)*c0(1); Alpha1(1)=Alpha1(1)*c0(1); Alpha2(1)=Alpha2(1)*c0(1);  
        Beta0(m)=1; Beta1(m)=1; Beta2(m)=1;
        for i=2:m
           Alpha0(i)=g0(i)*(Alpha0(i-1)*A_e(1,1)+Alpha1(i-1)*A_e(2,1)+Alpha2(i-1)*A_e(3,1));
           Alpha1(i)=g1(i)*(Alpha0(i-1)*A_e(1,2)+Alpha1(i-1)*A_e(2,2)+Alpha2(i-1)*A_e(3,2));
           Alpha2(i)=g2(i)*(Alpha0(i-1)*A_e(1,3)+Alpha1(i-1)*A_e(2,3)+Alpha2(i-1)*A_e(3,3));
           c0(i)=1/(Alpha0(i)+Alpha1(i)+Alpha2(i));
           Alpha0(i)=Alpha0(i)*c0(i); Alpha1(i)=Alpha1(i)*c0(i); Alpha2(i)=Alpha2(i)*c0(i); 
        end
        Beta0(m)=Beta0(m)*c0(m); Beta1(m)=Beta1(m)*c0(m); Beta2(m)=Beta2(m)*c0(m); 
        for i=2:m
           Beta0(m-i+1)=(A_e(1,1)*g0(m-i+2)*Beta0(m-i+2)+A_e(1,2)*g1(m-i+2)*Beta1(m-i+2)+A_e(1,3)*g2(m-i+2)*Beta2(m-i+2))*c0(m-i+1);
           Beta1(m-i+1)=(A_e(2,1)*g0(m-i+2)*Beta0(m-i+2)+A_e(2,2)*g1(m-i+2)*Beta1(m-i+2)+A_e(2,3)*g2(m-i+2)*Beta2(m-i+2))*c0(m-i+1);
           Beta2(m-i+1)=(A_e(3,1)*g0(m-i+2)*Beta0(m-i+2)+A_e(3,2)*g1(m-i+2)*Beta1(m-i+2)+A_e(3,3)*g2(m-i+2)*Beta2(m-i+2))*c0(m-i+1);
        end
        H0=Alpha0.*Beta0;
        H1=Alpha1.*Beta1;
        H2=Alpha2.*Beta2;
        
%         Alpha=zeros(3,m); Alpha(1,1)=pi0*g0(1);
%         Alpha(2,1)=pi1*g1(1);Alpha(3,1)=pi2*g2(1);
%         Beta=zeros(3,m); Beta(1,m)=1;Beta(2,m)=1;Beta(3,m)=1;
%         g=[g0;g1;g2];
%         for k=1:3
%            for i=2:m
%               Alpha(k,i)=g(k,i)*sum(Alpha(:,i-1).*A(:,k));
%               Beta(k,m-i+1)=sum(g(:,m-i+2).*Beta(:,m-i+2).*A(k,:)');
%            end
%         end
%         H0=Alpha(1,:).*Beta(1,:);
%         H1=Alpha(2,:).*Beta(2,:);
%         H2=Alpha(3,:).*Beta(3,:);

        H=H0+H1+H2;
        MAX=max(H1,H2); %max(H_k),k=1,-1���������˹�ͬ�ķ�ĸG
        MAX_IND=MAX==H1;
        POS1=find(MAX_IND==1);POS2=find(MAX_IND==0);
        LAMBDA=MAX./(H0); %��LAMBDA
        [LAM_sort,Ind]=sort(LAMBDA); %��LAMBDA������
        MAX=MAX./H; %�����H����ʵֵ
        MAX_sort=MAX(Ind); %���ݴ�LAMBDA��H������H^(i)
        SUM=sum((H1+H2)./H); %SOM�б��ĸ�Ĳ���
        
        for j=1:m
        	result(j)=sum(MAX_sort((m-j+1):m))/SUM;
        end
        cut=find(result-1+alpha>=0,1);
        OC=Ind(cut:m);
        delta=zeros(1,m);
        delta(intersect(OC,POS1))=1;delta(intersect(OC,POS2))=-1;

        a=a+sum(abs(THETA).*(THETA~=delta));
        b=b+sum(abs(THETA));
        c=c+sum(abs(delta).*(1-abs(THETA)));
	end
    MDR(t,r)=a/b;
    EFP(t,r)=c/rep2;
end
end
[n,lam,mean(MDR),mean(EFP)]
SDMD_result=[mean(MDR)',mean(EFP)'];
%csvwrite("SDMD_result3.csv",SDMD_result);
toc
%end
load train
sound(y,Fs)
